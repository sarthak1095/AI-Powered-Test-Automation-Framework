from behave.__main__ import main as behave_main
import os
import shutil
import stat
import argparse

def handle_remove_readonly(func, path, exc):
    """
    Clear readonly flag and retry removal
    """
    os.chmod(path, stat.S_IWRITE)
    func(path)

def clean_create_reports_dir(folder_path):
    """
    Ensure the reports directory exists and is clean.
    """
    if os.path.exists(folder_path):
        shutil.rmtree(folder_path, onerror=handle_remove_readonly)  # Force delete
    os.makedirs(folder_path, exist_ok=True)


if __name__ == "__main__":
    # Define the reports directory
    allure_reports_dir = "reports"
    screenshots_dir = "screenshots"

    clean_create_reports_dir(allure_reports_dir)
    clean_create_reports_dir(screenshots_dir)

    # Run Behave with specified tags and output format
    # Command line argument parsing for tags

    parser = argparse.ArgumentParser(description="Run Behave tests with specific tags.")
    parser.add_argument("--tags", default="", help="Tags to filter tests")
    args = parser.parse_args()

    #check if Behave_tags is set by jenkins

    tags = args.tags or os.getenv("BEHAVE_TAGS", "")


    behave_main([
        "--tags", tags,
        "--format", "allure_behave.formatter:AllureFormatter",
        "--outfile", "reports/allure-results"
    ])

#generate allure report

#allure generate reports/allure-results -o reports/allure-report --clean
#allure generate reports\allure-results -o reports\allure-report --clean
#allure open reports\allure-report

