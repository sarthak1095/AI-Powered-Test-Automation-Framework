from utils.openai_utils import generate_text, load_prompt

def generate_scenarios():
    #load the prompts
    prompt = load_prompt("contact_us_form")

    #generate the text using the prompt
    scenarios = generate_text(prompt)

    print("Generated Gherkin Scenarios:", scenarios)

    #save the scenarios to feature file

    feature_file_path = "features/contact_us_form.feature"

    #prevent overwriting existing file
    try:
        with open(feature_file_path, 'x') as file:
            file.write(scenarios)
        print(f"Feature file created at: {feature_file_path}")
    
    except FileExistsError:
        print(f"Feature file already exists at: {feature_file_path}. skipping creation.")

        
if __name__ == "__main__":
    generate_scenarios()