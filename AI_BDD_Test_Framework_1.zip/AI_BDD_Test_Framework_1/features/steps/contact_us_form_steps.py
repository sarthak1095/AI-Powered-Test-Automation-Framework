from behave import given, when, then
from utils.types import CustomContext
import logging
from playwright.sync_api import TimeoutError

#Set up logger
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('verify_logger')

# GIVEN steps
@given('I am on the Contact Us form.')
def given_on_contact_us_form(context: CustomContext):
    #[name="first_name"]
    context.page.goto("https://webdriveruniversity.com/Contact-Us/contactus.html")

# WHEN steps
@when('I enter "{value}" into the "{field}" field')
def when_enter_value_into_field(context: CustomContext, value, field):
    #[name="first_name"]
    field_selector = f'[name="{field}"]'
    if value == "\\n":
        logger.info(f"skipping field: {field} as indicated by '\\n'.")
        return
    logger.info(f"Entering value '{value}' into field '{field}'.")
    context.page.wait_for_selector(field_selector)
    context.page.fill(field_selector, value)


@when('I click the "{button}" button')
def when_click_button(context: CustomContext, button):
    button_selector = f'[value="{button}"]'
    context.page.wait_for_selector(button_selector)
    context.page.click(button_selector)
    #context.page.pause()
    
@then('I should see the message "{expected_message}"')
def verify_message(context: CustomContext, expected_message):
    message_selector = f'//*[contains(text(), "{expected_message}")] |  //body[contains(., "{expected_message}")]'
    try:
        logger.info(f"Waiting for message: {expected_message}")
        context.page.wait_for_selector(message_selector, timeout=5000)  # Wait for up to 5 seconds
        assert context.page.is_visible(message_selector)
        logger.info(f" message '{message_selector}' found on the page.")
    except TimeoutError:
        logger.error(f" message '{message_selector}' not found on the page.")
        assert False, f" message '{message_selector}' not found on the page"


@then('the "{field}" field should be empty')
def then_field_should_be_empty(context: CustomContext, field):
    field_selector = f'[name="{field}"]'
    try:
        logger.info(f"Checking if field '{field}' is empty.")
        context.page.wait_for_selector(field_selector)
        field_value = context.page.query_selector(field_selector).input_value()
        assert field_value == "", f"Field '{field}' is not empty, actual value: {field_value}"
        logger.info(f"Field '{field}' is empty.")
    except TimeoutError:
        logger.error(f"Field '{field}' not found on the page.")
        assert False, f"Field '{field}' not found on the page"
    except AssertionError as e:
        logger.error(f"Field '{field}' is not empty. {str(e)}")
        assert False, str(e)

