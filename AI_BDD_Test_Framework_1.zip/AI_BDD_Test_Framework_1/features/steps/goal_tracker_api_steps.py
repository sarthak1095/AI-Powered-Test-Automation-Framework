from behave import given, when, then
import requests

@given('the base URL "{base_url}"')
def step_impl(context, base_url):
    context.base_url = base_url

@when('I make a GET request to "{end_point}" endpoint')
def step_impl(context, end_point):
    response = requests.get(context.base_url + end_point)
    context.response = response

@then('the response should contain "{expected_value}"')
def step_impl(context, expected_value):
    assert context.response.status_code == 200, f"Expected 200 but got {context.response.status_code}"
    assert expected_value in context.response.text, f"'{expected_value}' not found in response: {context.response.text}"