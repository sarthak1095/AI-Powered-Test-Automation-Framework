from utils.openai_utils import generate_text

response = generate_text("write a 200 word essay on palak paneer")
print(response)
