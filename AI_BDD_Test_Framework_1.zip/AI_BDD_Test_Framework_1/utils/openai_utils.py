from openai import OpenAI
from config.prompts import prompts
import json

def initilize_client():
    with open('config/openai_key.json', 'r') as file:
        data = json.load(file)
        api_key = data["api_key"]
    return OpenAI(api_key=api_key, base_url="https://openrouter.ai/api/v1")


client = initilize_client()

def load_prompt(key):

    return prompts.get(key, "Prompt not found.")

def generate_text(prompt):
    message = [{"role": "user", "content": prompt}]
    completion = client.chat.completions.create(
        extra_body={},
        model="deepseek/deepseek-r1-distill-llama-70b:free",
        messages=message,
        max_tokens=1000,
        temperature=0.7
    )


    return completion.choices[0].message.content.strip()


    