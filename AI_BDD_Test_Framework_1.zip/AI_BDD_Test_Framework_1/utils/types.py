from playwright.sync_api import sync_playwright, Playwright, Browser, Page

class CustomContext:
    playwright: Playwright  # Represents the Playwright instance
    browser: Browser        # Represents the browser instance
    page: Page              # Represents the page instance